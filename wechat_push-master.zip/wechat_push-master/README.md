# wechat_push  
#利用微信推送通用漏洞4.0  
#XXX表示通过server酱获取的微信推送接口  
#数据保存在当前路径下的olddata.csv  
#当前代码运行需要预先安装numpy pandas requests库，一般anaconda的环境就行  
#可以通过更改time_sleep设置爬取间隔时间  
注：  
    github哪个api需要翻墙  
    如果一直什么都不输出说明是遇到重复数据了  
    代码运行的时候不要打开olddata.csv文件，否则会报错
